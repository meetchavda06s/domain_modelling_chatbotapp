document.addEventListener("DOMContentLoaded", () => {
    const userNameInput = document.getElementById("userName");

    // Load saved name
    const savedName = sessionStorage.getItem("userData");
    if (savedName) {
        userNameInput.value = savedName;
    }

    // Save username on blur
    userNameInput.addEventListener("blur", () => {
        sessionStorage.setItem("userData", userNameInput.value);
    });
});

document.addEventListener("DOMContentLoaded", () => {
    const userInput = document.getElementById("userInput");
    const sendButton = document.getElementById("sendButton");
    const chatBox = document.getElementById("chatBox");

    // Function to add a message to the chatbox
    function appendMessage(text, sender) {
        let messageDiv = document.createElement("div");
        messageDiv.classList.add("chat-message");
        messageDiv.textContent = text;

        // Style based on sender (User or Bot)
        if (sender === "user") {
            messageDiv.classList.add("user-message");
        } else {
            messageDiv.classList.add("bot-message");
        }

        chatBox.appendChild(messageDiv);
        chatBox.scrollTop = chatBox.scrollHeight; // Auto-scroll
    }

    // Function to send a message
    function sendMessage() {
        let message = userInput.value.trim();
        if (message === "") return;

        // Append user message
        appendMessage(message, "user");

        // Clear input field
        userInput.value = "";

        // Simulate bot response after 1 second (Replace with API call)
        setTimeout(() => {
            appendMessage("Processing your scenario...", "bot");
        }, 1000);
    }

    // Send message when clicking the button
    sendButton.addEventListener("click", sendMessage);

    // Send message when pressing Enter
    userInput.addEventListener("keypress", (event) => {
        if (event.key === "Enter") {
            event.preventDefault();
            sendMessage();
        }
    });
});
