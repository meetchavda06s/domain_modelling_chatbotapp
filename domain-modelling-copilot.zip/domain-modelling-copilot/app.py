from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Simple chatbot response logic
def chatbot_response(user_input):
    responses = {
        "hello": "Hi there! I am a domain modeling copilot.",
        "what do you do": "I help in domain modeling by generating relevant UML diagrams.",
        "bye": "Goodbye! Have a great day!",
    }
    return responses.get(user_input.lower(), "I am not sure, but I can help with domain models!")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json["message"]
    bot_reply = chatbot_response(user_message)
    return jsonify({"response": bot_reply})

if __name__ == "__main__":
    app.run(debug=True)
